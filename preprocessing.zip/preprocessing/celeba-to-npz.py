
import pickle, sys
import numpy as np

from os import listdir
from os.path import isfile, join
from collections import defaultdict
from PIL import Image
from tqdm import tqdm


img_dir = 'kaggle/CelebA-64'


np.set_printoptions(precision=3, threshold=sys.maxsize)


mask_attr = np.ones(shape=(40,3))

with open('which_attributes_simple.txt', 'r') as file:
    for n, line in enumerate(lines):
        mask_attr[n] = line.split()


X = []
Y = []
which_columns = [i for i in range(40) if mask_attr[i,1] == 1]
print(which_columns)


with open('kaggle/list_attr_celeba.csv', 'rt') as fp:
    lines = fp.readlines()
    columns = ['filename'] + lines[0].split(',')
    columns = columns[2:]
    names = np.array(lines[0][1:])
    for line in lines[1:]:
        values = [value.strip() for value in line.split(',')]
       
        assert len(values[1:]) == len(columns), str(len(values))+' '+str(len(columns))
	
        img_filename = values[0]
        list_attr = (np.array(list(map(int, values[1:]))) > 0).astype(int)[which_columns]

        if list_attr[0]+list_attr[1]+list_attr[2]+list_attr[3] +list_attr[5] == 0:
           passed = False
        elif list_attr[0] >0 and list_attr[1]+list_attr[2]+list_attr[3] +list_attr[5] > 0:
           passed = False
        else:
           passed = True
        	
        with Image.open(join(img_dir, img_filename)) as im:
            print(img_filename, ' ',passed)
            im = im.convert('RGB')
            x = np.asarray(im).reshape(64,64,3)
        if passed: X.append(x)

        attributes = (np.array(list(map(int, values[1:]))) > 0).astype(int)
        if passed: Y.append(attributes)

        #print(x.shape, x)
        # (64, 64, 3), values in {0, ..., 255}

        #print(attributes.shape, attributes)
        # (40,), values in {0, 1}
        

#quit()    
columns = [i for i in range(40) if mask_attr[i,1] == 1]
Y = np.array(Y)
Y = Y[:, columns]
print('columns:', columns)
'''
Z = []
with open('Anno/list_landmarks_celeba.txt', 'r') as fp:
    lines = fp.readlines()
    columns = ['filename'] + lines[1].split()
    for line in lines[2:]:
        values = line.split()
        assert len(values) == len(columns)
        attributes = (np.array([float(j) for j in values[1:]]))
        Z.append(attributes)
Z = np.array(Z)

delta = np.array([np.max(Z[:,i]) - np.min(Z[:,i]) for i in range(3) ])
zmin = np.array([np.min(Z[:,i]) for i in range(3)]) 


for i in range(len(Z)):
    Z[i] = (Z[i] - zmin)/delta

    
latents = np.concatenate((Y,Z), axis=1 )
'''
latents=Y

print(len(X), np.shape(X[0]))

np.savez(
    'celebA64-10-dim.npz',
    X=np.array(X, dtype=np.uint8),
    Y=np.array(latents, dtype=np.uint8),
)
