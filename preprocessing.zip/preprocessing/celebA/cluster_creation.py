import pickle
from kmodes.kmodes import KModes
import numpy as np
from sklearn.linear_model import LogisticRegression

data = np.load('celebA64-10-dim.npz')
Z = np.array(data['Y']).astype(np.int)

print('Shape of Z:', np.shape(Z))
print(Z[:5])

km = KModes(n_clusters=4, init='Huang', n_init=10, verbose=1)

# Print the cluster centroids

np.random.shuffle(Z)

clusters = km.fit_predict(Z[:10000])
print(km.cluster_centroids_)

Y = np.array(km.predict(Z))

l = len(Y)
total = []
for i in range(10):
    mask = (Y == i)
    total.append(len(Y[mask]))
    
print(np.array(total)/l)


log_reg = LogisticRegression(max_iter=10000)
log_reg.fit(Z,Y)
print('Separation:', log_reg.score(Z,Y))


# It is important to use binary access
with open('try_km.pickle', 'wb') as f:
    pickle.dump(km, f)
    
with open('try_km.pickle', 'rb') as f:
    km = pickle.load(f)
