from kmodes.kmodes import KModes
import numpy as np
import pickle


np.random.seed(42)

X = np.load('attributes.npy')
X = X[:,:-2]

np.random.shuffle(X)

X = X[:3*10**4]

km = KModes(n_clusters=10, init='Huang', n_init=5, verbose=1)

clusters = km.fit_predict(X)

# Print the cluster centroids
print(km.cluster_centroids_)

X = np.load('attributes.npy')

np.random.shuffle(X)

labels = km.predict(X[:10**5, :-2])
labels = (np.asarray(labels, dtype=int))

n_tot = []
l = len(labels)
for i in range(10):
	mask = (labels == i)
	n_tot.append( len(labels[mask])/l)

print('Perc of clusters', n_tot)

import pickle

# It is important to use binary access
with open('km.pickle', 'wb') as f:
    pickle.dump(km, f)
    
with open('km.pickle', 'rb') as f:
    km = pickle.load(f)
    print('All good')



