import numpy as np
import matplotlib.pyplot as plt

data = np.load('mpi3d/mpi3d_toy_full.npz')
images = data['X']

attributes = np.zeros(shape=(len(images), 7))

j = 0
for i1 in range(6):
	for i2 in range(6):
		for i3 in range(2):
			for i4 in range(3):
				for i5 in range(3):
					for x in range(40):
						for y in range(40):
							
							attributes[j,:] = np.array([i1,i2,i3,i4,i5,x,y])			
							j += 1

print(np.shape(attributes))

np.save('mpi3d/attributes.npy', attributes)

#perm = np.random.permutation(len(images))

#X = images[perm][:25000]
#Y = attributes[perm][:25000]

np.savez(
    'mpi3d/mpi3d_toy.npz',
    X=np.array(X, dtype=np.uint8),
    Y=np.array(Y, dtype=np.uint8),
)

